You need to create a PHPMyAdmin dump of your running site.

Here are the settings:
  * Select all tables
  * Structure: DROP (and nothing else), Data: Complete Inserts, Extended Inserts (and nothing else), Save As File: SQL

